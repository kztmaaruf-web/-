import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:home_widget/home_widget.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';

// ---------- الألوان (الوضع الداكن) ----------
const Color kBg = Color(0xFF0F1517);
const Color kCard = Color(0xFF1A2428);
const Color kBar = Color(0xFF12353F);
const Color kAccent = Color(0xFF4FB3C8);
const Color kButton = Color(0xFF0D5C75);
const Color kGreen = Color(0xFF3DBE7A);
const Color kMuted = Color(0xFF9AA8AC);

const List<String> kSurahs = [
  'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف',
  'الأنفال', 'التوبة', 'يونس', 'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر',
  'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه', 'الأنبياء', 'الحج', 'المؤمنون',
  'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم',
  'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر',
  'غافر', 'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد',
  'الفتح', 'الحجرات', 'ق', 'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن',
  'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة', 'الصف', 'الجمعة',
  'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة',
  'المعارج', 'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان',
  'المرسلات', 'النبأ', 'النازعات', 'عبس', 'التكوير', 'الانفطار', 'المطففين',
  'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد',
  'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة',
  'الزلزلة', 'العاديات', 'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل',
  'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر', 'المسد', 'الإخلاص',
  'الفلق', 'الناس',
];

void main() {
  runApp(const FullQuranKhatmaApp());
}

class FullQuranKhatmaApp extends StatelessWidget {
  const FullQuranKhatmaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ختمة القرآن الكبرى',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kButton,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: kBg,
        fontFamily: 'Cairo',
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kButton,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: kBg,
        fontFamily: 'Cairo',
      ),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    KhatmaHomeScreen(),
    AudioAndTafseerScreen(),
    RemindersScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // IndexedStack يبقي التلاوة شغالة عند التنقل بين الشاشات
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'الورد اليومي'),
          NavigationDestination(icon: Icon(Icons.headset), label: 'التلاوة والتفسير'),
          NavigationDestination(icon: Icon(Icons.notifications_active), label: 'التذكيرات'),
        ],
      ),
    );
  }
}

PreferredSizeWidget _bar(String title) => AppBar(
      title: Text(title),
      centerTitle: true,
      backgroundColor: kBar,
      foregroundColor: Colors.white,
    );

// ---------------- 1. شاشة الورد اليومي ----------------
class KhatmaHomeScreen extends StatefulWidget {
  const KhatmaHomeScreen({super.key});

  @override
  State<KhatmaHomeScreen> createState() => _KhatmaHomeScreenState();
}

class _KhatmaHomeScreenState extends State<KhatmaHomeScreen> {
  static const List<String> _prayers = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

  int currentDay = 1;
  int pagesReadToday = 0;
  final int dailyTarget = 20;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String _today() {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  String _hint() {
    if (pagesReadToday >= dailyTarget) return 'ما شاء الله، أتممت ورد اليوم';
    return 'القراءة القادمة: بعد صلاة ${_prayers[pagesReadToday ~/ 4]}';
  }

  // تحميل التقدم المحفوظ، وإذا بدأ يوم جديد ينتقل لليوم التالي ويصفّر صفحات اليوم
  Future<void> _load() async {
    try {
      final day = await HomeWidget.getWidgetData<int>('day', defaultValue: 1) ?? 1;
      final pages = await HomeWidget.getWidgetData<int>('pages', defaultValue: 0) ?? 0;
      final last = await HomeWidget.getWidgetData<String>('lastDate', defaultValue: '') ?? '';
      var d = day;
      var p = pages;
      if (last.isNotEmpty && last != _today()) {
        d = d < 30 ? d + 1 : 30;
        p = 0;
      }
      if (!mounted) return;
      setState(() {
        currentDay = d;
        pagesReadToday = p;
      });
      await _save();
    } catch (_) {}
  }

  // حفظ التقدم وتحديث ودجت الشاشة الرئيسية
  Future<void> _save() async {
    try {
      await HomeWidget.saveWidgetData<int>('day', currentDay);
      await HomeWidget.saveWidgetData<int>('pages', pagesReadToday);
      await HomeWidget.saveWidgetData<int>('target', dailyTarget);
      await HomeWidget.saveWidgetData<String>('lastDate', _today());
      await HomeWidget.saveWidgetData<String>('hint', _hint());
      await HomeWidget.updateWidget(
        name: 'KhatmaWidgetProvider',
        androidName: 'KhatmaWidgetProvider',
      );
    } catch (_) {}
  }

  void _markPrayerDone(int pages) {
    setState(() {
      if (pagesReadToday + pages <= dailyTarget) {
        pagesReadToday += pages;
      }
    });
    _save();
  }

  @override
  Widget build(BuildContext context) {
    double progress = pagesReadToday / dailyTarget;

    return Scaffold(
      appBar: _bar('ختمة القرآن - غير ربحي'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: kCard,
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    'اليوم $currentDay من 30',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: kAccent),
                  ),
                  const SizedBox(height: 8),
                  Text('إنجازك اليوم: $pagesReadToday / $dailyTarget صفحة'),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 12,
                    borderRadius: BorderRadius.circular(6),
                    color: kGreen,
                    backgroundColor: Colors.white12,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('تسجيل القراءة بعد الصلوات (4 صفحات كل صلاة):',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ..._prayers.map((prayer) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  tileColor: kCard,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  leading: const Icon(Icons.check_circle_outline, color: kAccent),
                  title: Text('صلاة $prayer'),
                  subtitle: const Text('المطلوب: 4 صفحات', style: TextStyle(color: kMuted)),
                  trailing: ElevatedButton(
                    onPressed: pagesReadToday < dailyTarget ? () => _markPrayerDone(4) : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kButton,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('تمت القراءة'),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

// ---------------- 2. شاشة الاستماع (الشيخ هيثم الدخين) ----------------
class AudioAndTafseerScreen extends StatefulWidget {
  const AudioAndTafseerScreen({super.key});

  @override
  State<AudioAndTafseerScreen> createState() => _AudioAndTafseerScreenState();
}

class _AudioAndTafseerScreenState extends State<AudioAndTafseerScreen> {
  static const String _apiUrl = 'https://www.mp3quran.net/api/v3/reciters?language=ar';

  final AudioPlayer _player = AudioPlayer();
  String? _server;
  int _selected = 1;
  int? _loaded;
  bool _loadingReciter = false;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // يجلب رابط سيرفر الشيخ هيثم الدخين من واجهة mp3quran
  Future<void> _loadReciter() async {
    if (_loadingReciter) return;
    _loadingReciter = true;
    try {
      final res = await http.get(Uri.parse(_apiUrl)).timeout(const Duration(seconds: 15));
      final data = jsonDecode(utf8.decode(res.bodyBytes));
      final List reciters = data['reciters'] as List;
      final reciter = reciters.cast<dynamic>().firstWhere(
            (e) => (e['name'] as String).contains('الدخين'),
            orElse: () => null,
          );
      if (reciter != null) {
        dynamic best;
        int bestTotal = -1;
        for (final m in (reciter['moshaf'] as List)) {
          final total = int.tryParse('${m['surah_total']}') ?? 0;
          final server = (m['server'] ?? '') as String;
          if (server.isNotEmpty && total > bestTotal) {
            best = m;
            bestTotal = total;
          }
        }
        if (best != null) {
          String s = best['server'] as String;
          if (!s.endsWith('/')) s = '$s/';
          _server = s;
        }
      }
    } catch (_) {
      // يتم التعامل معها في _playSurah
    } finally {
      _loadingReciter = false;
    }
  }

  Future<void> _playSurah(int n) async {
    setState(() => _selected = n);
    if (_server == null) await _loadReciter();
    if (_server == null) {
      _snack('تعذر الاتصال بمصدر التلاوة. تأكد من الإنترنت وحاول مرة أخرى.');
      return;
    }
    try {
      final url = '$_server${n.toString().padLeft(3, '0')}.mp3';
      await _player.setUrl(url);
      setState(() => _loaded = n);
      _player.play();
    } catch (_) {
      _snack('تعذر تشغيل هذه السورة. حاول مرة أخرى.');
    }
  }

  void _toggle() {
    if (_loaded != _selected) {
      _playSurah(_selected);
    } else if (_player.playing) {
      _player.pause();
    } else {
      _player.play();
    }
  }

  void _skip(int seconds) {
    final target = _player.position + Duration(seconds: seconds);
    _player.seek(target < Duration.zero ? Duration.zero : target);
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _bar('التلاوة والتفسير الميسر'),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: kSurahs.length + 3,
        itemBuilder: (context, i) {
          if (i == 0) return _playerCard();
          if (i == 1) {
            return const Padding(
              padding: EdgeInsets.only(top: 16, bottom: 8),
              child: Text('اختر السورة:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            );
          }
          if (i == kSurahs.length + 2) return _tafseerCard();
          final n = i - 1;
          final selected = n == _selected;
          return Container(
            margin: const EdgeInsets.only(bottom: 6),
            child: ListTile(
              tileColor: selected ? kBar : kCard,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              leading: CircleAvatar(
                radius: 14,
                backgroundColor: kButton,
                child: Text('$n', style: const TextStyle(fontSize: 12, color: Colors.white)),
              ),
              title: Text('سورة ${kSurahs[n - 1]}'),
              trailing: Icon(
                selected && _loaded == n ? Icons.graphic_eq : Icons.play_arrow,
                color: kAccent,
              ),
              onTap: () => _playSurah(n),
            ),
          );
        },
      ),
    );
  }

  Widget _playerCard() {
    return Card(
      color: kCard,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Icon(Icons.headset, size: 48, color: kAccent),
            const SizedBox(height: 8),
            Text('سورة ${kSurahs[_selected - 1]}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Text('القارئ: الشيخ هيثم الدخين', style: TextStyle(color: kMuted)),
            const SizedBox(height: 8),
            StreamBuilder<Duration>(
              stream: _player.positionStream,
              builder: (context, snap) {
                final pos = snap.data ?? Duration.zero;
                final dur = _player.duration ?? Duration.zero;
                final max = dur.inMilliseconds.toDouble();
                final value = max > 0 ? pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble() : 0.0;
                return Column(
                  children: [
                    Slider(
                      value: value,
                      min: 0,
                      max: max > 0 ? max : 1,
                      onChanged: max > 0 ? (v) => _player.seek(Duration(milliseconds: v.round())) : null,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_fmt(pos), style: const TextStyle(color: kMuted, fontSize: 12)),
                          Text(_fmt(dur), style: const TextStyle(color: kMuted, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () => _skip(-10), icon: const Icon(Icons.replay_10, size: 30)),
                StreamBuilder<PlayerState>(
                  stream: _player.playerStateStream,
                  builder: (context, snap) {
                    final st = snap.data;
                    final busy = st?.processingState == ProcessingState.loading ||
                        st?.processingState == ProcessingState.buffering;
                    if (busy) {
                      return const Padding(
                        padding: EdgeInsets.all(12),
                        child: SizedBox(width: 32, height: 32, child: CircularProgressIndicator()),
                      );
                    }
                    final playing = st?.playing ?? false;
                    return IconButton(
                      onPressed: _toggle,
                      iconSize: 52,
                      color: kAccent,
                      icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
                    );
                  },
                ),
                IconButton(onPressed: () => _skip(10), icon: const Icon(Icons.forward_10, size: 30)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tafseerCard() {
    return const Padding(
      padding: EdgeInsets.only(top: 16),
      child: Card(
        color: kCard,
        elevation: 0,
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            'التفسير الميسر لورد اليوم سيظهر هنا ليعينك على تدبر القرآن الكريم أثناء القراءة.',
            style: TextStyle(height: 1.6, color: kMuted),
          ),
        ),
      ),
    );
  }
}

// ---------------- 3. شاشة التنبيهات والإشعارات ----------------
class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  bool isNotificationEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _bar('تنبيهات الورد القرآني'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('تفعيل التذكير اليومي بالورد'),
            subtitle: const Text('إرسال تنبيه في الأوقات المحددة لقراءة الورد',
                style: TextStyle(color: kMuted)),
            value: isNotificationEnabled,
            onChanged: (val) => setState(() => isNotificationEnabled = val),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.access_time, color: kAccent),
            title: const Text('وقت التذكير الصباحي'),
            subtitle: const Text('07:00 صباحاً (بعد الفجر)', style: TextStyle(color: kMuted)),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.access_time, color: kAccent),
            title: const Text('وقت التذكير المسائي'),
            subtitle: const Text('08:00 مساءً (بعد العشاء)', style: TextStyle(color: kMuted)),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
