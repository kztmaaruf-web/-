# Khatma App – ختمة القرآن

## Get the APK (no installs needed)
1. Create a new empty repository on github.com.
2. Upload ALL files from this folder (keep the `.github` and `android_overlay` folders) to the `main` branch.
3. Open the repo's **Actions** tab -> "Build APK" -> wait ~5-8 minutes for the green check.
4. Download the `khatma-apk` artifact, unzip it, and install `app-release.apk` on your phone.

## Add the home-screen widget
Long-press an empty spot on the home screen -> Widgets -> "ختمة القرآن" -> drag it to the screen.
The widget shows today's progress and the next reading time; tapping it opens the app.

## Build locally instead
    flutter create . --platforms=android --org com.khatma --project-name khatma_app
    python3 android_overlay/patch_android.py
    flutter pub get
    flutter build apk --release
