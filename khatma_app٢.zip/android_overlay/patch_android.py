"""Run after `flutter create`: copies the widget files into android/ and patches the manifest."""
import pathlib
import shutil

root = pathlib.Path(__file__).resolve().parent
android = root.parent / "android" / "app" / "src" / "main"

kt_dir = android / "kotlin" / "com" / "khatma" / "khatma_app"
kt_dir.mkdir(parents=True, exist_ok=True)
shutil.copy(root / "kotlin" / "KhatmaWidgetProvider.kt", kt_dir)

for sub in ("layout", "xml", "drawable"):
    dst = android / "res" / sub
    dst.mkdir(parents=True, exist_ok=True)
    for f in (root / "res" / sub).iterdir():
        shutil.copy(f, dst)

manifest = android / "AndroidManifest.xml"
text = manifest.read_text(encoding="utf-8")

if "android.permission.INTERNET" not in text:
    text = text.replace(
        "<application",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
        1,
    )

receiver = """
        <receiver android:name=".KhatmaWidgetProvider" android:exported="true" android:label="ختمة القرآن">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/khatma_widget_info"/>
        </receiver>
    """

if "KhatmaWidgetProvider" not in text:
    text = text.replace("</application>", receiver + "</application>", 1)

manifest.write_text(text, encoding="utf-8")
print(text)
