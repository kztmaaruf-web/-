package com.khatma.khatma_app

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider

class KhatmaWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.khatma_widget).apply {
                val pendingIntent = HomeWidgetLaunchIntent.getActivity(
                    context,
                    MainActivity::class.java
                )
                setOnClickPendingIntent(R.id.widget_root, pendingIntent)

                val day = widgetData.getInt("day", 1)
                val pages = widgetData.getInt("pages", 0)
                val target = widgetData.getInt("target", 20)
                val hint = widgetData.getString("hint", "افتح التطبيق لتبدأ ورد اليوم") ?: ""

                setTextViewText(R.id.widget_day, "ختمة القرآن · اليوم $day من 30")
                setTextViewText(R.id.widget_pages, "$pages / $target صفحة")
                setTextViewText(R.id.widget_hint, hint)
                setProgressBar(R.id.widget_progress, target, pages, false)
            }
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
